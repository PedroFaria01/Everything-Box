export type MouseButton = 'left' | 'right' | 'middle'

export type ExecutionMode = 'continuous' | 'count'

export type ClickPositionMode = 'cursor' | 'fixed'

export interface Point {
  x: number
  y: number
}

export interface AutoClickerConfig {
  intervalMs: number
  mouseButton: MouseButton
  executionMode: ExecutionMode
  clickCount: number
  initialDelayMs: number
  positionMode: ClickPositionMode
  fixedPosition: Point | null
}

export interface AutoClickerStatus {
  running: boolean
  clicksExecuted: number
  elapsedMs: number
  startedAt: number | null
}

export interface ShortcutState {
  accelerator: string
  registered: boolean
}

export type AppErrorCode =
  | 'INVALID_SHORTCUT'
  | 'SHORTCUT_UNAVAILABLE'
  | 'SHORTCUT_REGISTER_FAILED'
  | 'CLICK_EXECUTION_FAILED'
  | 'INVALID_INTERVAL'
  | 'INVALID_COUNT'
  | 'INVALID_COORDINATES'
  | 'SETTINGS_LOAD_FAILED'
  | 'SETTINGS_SAVE_FAILED'
  | 'AUTOMATION_LIB_UNAVAILABLE'
  | 'ALREADY_RUNNING'
  | 'CLOSED_WHILE_RUNNING'
  | 'UNKNOWN'

export interface AppError {
  code: AppErrorCode
  message: string
}

export type TrayBehavior = 'ask' | 'minimize' | 'close'

export interface AppSettings {
  autoClicker: AutoClickerConfig
  shortcut: string
  trayBehavior: TrayBehavior
  interfacePrefs: {
    theme: 'dark'
  }
}

export const DEFAULT_SHORTCUT = 'F6'

export const DEFAULT_AUTO_CLICKER_CONFIG: AutoClickerConfig = {
  intervalMs: 1000,
  mouseButton: 'left',
  executionMode: 'continuous',
  clickCount: 10,
  initialDelayMs: 0,
  positionMode: 'cursor',
  fixedPosition: null
}

export const DEFAULT_SETTINGS: AppSettings = {
  autoClicker: DEFAULT_AUTO_CLICKER_CONFIG,
  shortcut: DEFAULT_SHORTCUT,
  trayBehavior: 'ask',
  interfacePrefs: {
    theme: 'dark'
  }
}

// Limites de segurança para evitar uso excessivo de CPU / cliques inválidos
export const MIN_INTERVAL_MS = 20 // 50 cliques/segundo no máximo
export const MAX_INTERVAL_MS = 60_000
export const MIN_CLICK_COUNT = 1
export const MAX_CLICK_COUNT = 1_000_000
export const MAX_INITIAL_DELAY_MS = 3_600_000
