import { Radio, RadioGroup } from '@heroui/react'
import { useAppStore } from '../store/appStore'
import { desktopApi } from '../services/desktopApi'
import type { TrayBehavior } from '../types'

export function Settings(): JSX.Element {
  const settings = useAppStore((s) => s.settings)
  const setSettings = useAppStore((s) => s.setSettings)
  const currentShortcut = useAppStore((s) => s.currentShortcut)

  const handleTrayBehaviorChange = async (value: TrayBehavior): Promise<void> => {
    const next = { ...settings, trayBehavior: value }
    setSettings(next)
    await desktopApi().saveSettings(next)
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="glass-card rounded-2xl p-4">
        <h2 className="mb-3 text-sm font-semibold text-gray-100">Configurações</h2>

        <div className="mb-4">
          <p className="mb-1 text-xs text-gray-400">Atalho global atual</p>
          <span className="rounded-md border border-white/10 bg-white/5 px-2 py-1 font-mono text-xs text-accent-cyan">
            {currentShortcut}
          </span>
          <p className="mt-1 text-[11px] text-gray-500">
            Altere o atalho na tela do Auto Clicker.
          </p>
        </div>

        <RadioGroup
          label="Ao clicar em fechar (X)"
          size="sm"
          value={settings.trayBehavior}
          onValueChange={(value) => void handleTrayBehaviorChange(value as TrayBehavior)}
        >
          <Radio value="ask" description="Mostrar essa pergunta toda vez">
            Perguntar
          </Radio>
          <Radio value="minimize" description="O app continua rodando na bandeja">
            Minimizar para a bandeja
          </Radio>
          <Radio value="close" description="Encerra o processo e para qualquer automação">
            Fechar o aplicativo
          </Radio>
        </RadioGroup>
      </div>
    </div>
  )
}
