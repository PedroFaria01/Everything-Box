import { ipcMain, BrowserWindow } from 'electron'
import type { AutoClickerConfig, AppSettings } from '../../renderer/src/types'
import {
  startAutoClicker,
  stopAutoClicker,
  getStatus,
  onStatusChange,
  captureMousePosition
} from '../auto-clicker'
import { registerGlobalShortcut, validateAccelerator, getCurrentAccelerator } from '../shortcuts'
import { loadSettings, saveSettings } from '../store'

function toErrorPayload(error: unknown): { code: string; message: string } {
  const message = error instanceof Error ? error.message : 'Erro desconhecido.'
  const code = error instanceof Error ? error.constructor.name : 'UNKNOWN'
  return { code, message }
}

export function registerIpcHandlers(mainWindow: BrowserWindow, toggleFromShortcut: () => void): void {
  // Repassa mudanças de status do Auto Clicker para o renderer
  onStatusChange((status) => {
    if (!mainWindow.isDestroyed()) {
      mainWindow.webContents.send('auto-clicker:status', status)
    }
  })

  ipcMain.handle('auto-clicker:start', (_event, config: AutoClickerConfig) => {
    try {
      startAutoClicker(config)
      return { ok: true }
    } catch (error) {
      return { ok: false, error: toErrorPayload(error) }
    }
  })

  ipcMain.handle('auto-clicker:stop', () => {
    stopAutoClicker()
    return { ok: true }
  })

  ipcMain.handle('auto-clicker:get-status', () => getStatus())

  ipcMain.handle('auto-clicker:capture-position', async () => {
    try {
      const point = await captureMousePosition()
      return { ok: true, point }
    } catch (error) {
      return { ok: false, error: toErrorPayload(error) }
    }
  })

  ipcMain.handle('settings:get', () => loadSettings())

  ipcMain.handle('settings:save', (_event, settings: AppSettings) => {
    try {
      saveSettings(settings)
      return { ok: true }
    } catch (error) {
      return { ok: false, error: toErrorPayload(error) }
    }
  })

  ipcMain.handle('shortcut:validate', (_event, accelerator: string) => {
    try {
      validateAccelerator(accelerator)
      return { ok: true }
    } catch (error) {
      return { ok: false, error: toErrorPayload(error) }
    }
  })

  ipcMain.handle('shortcut:register', (_event, accelerator: string) => {
    try {
      const registered = registerGlobalShortcut(accelerator, toggleFromShortcut)
      return { ok: true, accelerator: registered }
    } catch (error) {
      return { ok: false, error: toErrorPayload(error) }
    }
  })

  ipcMain.handle('shortcut:get-current', () => getCurrentAccelerator())

  ipcMain.handle('window:minimize', () => {
    mainWindow.minimize()
  })

  ipcMain.handle('window:minimize-to-tray', () => {
    mainWindow.hide()
  })

  ipcMain.handle('window:close', () => {
    mainWindow.close()
  })
}
