import Store from 'electron-store'
import type { AppSettings } from '../../renderer/src/types'
import { DEFAULT_SETTINGS } from '../../renderer/src/types'

interface StoreSchema {
  settings: AppSettings
}

let store: Store<StoreSchema> | null = null

function getStore(): Store<StoreSchema> {
  if (!store) {
    store = new Store<StoreSchema>({
      name: 'caixa-de-tudo-settings',
      defaults: {
        settings: DEFAULT_SETTINGS
      },
      clearInvalidConfig: true
    })
  }
  return store
}

export function loadSettings(): AppSettings {
  try {
    const s = getStore()
    const saved = s.get('settings')
    // Faz merge defensivo com os defaults, caso versões antigas faltem campos novos
    return {
      ...DEFAULT_SETTINGS,
      ...saved,
      autoClicker: { ...DEFAULT_SETTINGS.autoClicker, ...saved?.autoClicker },
      interfacePrefs: { ...DEFAULT_SETTINGS.interfacePrefs, ...saved?.interfacePrefs }
    }
  } catch (error) {
    console.error('[store] Falha ao carregar configurações:', error)
    return DEFAULT_SETTINGS
  }
}

export function saveSettings(settings: AppSettings): void {
  try {
    const s = getStore()
    s.set('settings', settings)
  } catch (error) {
    console.error('[store] Falha ao salvar configurações:', error)
    throw error
  }
}
