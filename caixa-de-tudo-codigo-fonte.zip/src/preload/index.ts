import { contextBridge, ipcRenderer } from 'electron'
import type { AutoClickerConfig, AutoClickerStatus, AppSettings } from '../renderer/src/types'

type IpcResult<T = undefined> =
  | { ok: true } & (T extends undefined ? unknown : { [K in keyof T]: T[K] })
  | { ok: false; error: { code: string; message: string } }

const desktopAPI = {
  startAutoClicker: (config: AutoClickerConfig): Promise<IpcResult> =>
    ipcRenderer.invoke('auto-clicker:start', config),

  stopAutoClicker: (): Promise<IpcResult> => ipcRenderer.invoke('auto-clicker:stop'),

  getAutoClickerStatus: (): Promise<AutoClickerStatus> => ipcRenderer.invoke('auto-clicker:get-status'),

  captureMousePosition: (): Promise<
    { ok: true; point: { x: number; y: number } } | { ok: false; error: { code: string; message: string } }
  > => ipcRenderer.invoke('auto-clicker:capture-position'),

  onAutoClickerStatus: (callback: (status: AutoClickerStatus) => void): (() => void) => {
    const listener = (_event: unknown, status: AutoClickerStatus): void => callback(status)
    ipcRenderer.on('auto-clicker:status', listener)
    return () => ipcRenderer.removeListener('auto-clicker:status', listener)
  },

  onAutoClickerStartRequested: (callback: (config: AutoClickerConfig) => void): (() => void) => {
    const listener = (_event: unknown, config: AutoClickerConfig): void => callback(config)
    ipcRenderer.on('auto-clicker:start-requested', listener)
    return () => ipcRenderer.removeListener('auto-clicker:start-requested', listener)
  },

  getSettings: (): Promise<AppSettings> => ipcRenderer.invoke('settings:get'),

  saveSettings: (settings: AppSettings): Promise<IpcResult> =>
    ipcRenderer.invoke('settings:save', settings),

  validateShortcut: (
    accelerator: string
  ): Promise<{ ok: true } | { ok: false; error: { code: string; message: string } }> =>
    ipcRenderer.invoke('shortcut:validate', accelerator),

  registerShortcut: (
    accelerator: string
  ): Promise<
    | { ok: true; accelerator: string }
    | { ok: false; error: { code: string; message: string } }
  > => ipcRenderer.invoke('shortcut:register', accelerator),

  getCurrentShortcut: (): Promise<string | null> => ipcRenderer.invoke('shortcut:get-current'),

  minimizeWindow: (): Promise<void> => ipcRenderer.invoke('window:minimize'),

  minimizeToTray: (): Promise<void> => ipcRenderer.invoke('window:minimize-to-tray'),

  closeWindow: (): Promise<void> => ipcRenderer.invoke('window:close'),

  onAskCloseBehavior: (callback: () => void): (() => void) => {
    const listener = (): void => callback()
    ipcRenderer.on('window:ask-close-behavior', listener)
    return () => ipcRenderer.removeListener('window:ask-close-behavior', listener)
  },

  resolveCloseBehavior: (choice: 'minimize' | 'close', remember: boolean): Promise<void> =>
    ipcRenderer.invoke('window:resolve-close-behavior', choice, remember)
}

export type DesktopAPI = typeof desktopAPI

contextBridge.exposeInMainWorld('desktopAPI', desktopAPI)
